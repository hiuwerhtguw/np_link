<?php
$name = isset($_POST['test']) ? htmlspecialchars($_POST['test']) : '';
$servername = "localhost";
$username = "feednui";
$password = "W7YwSi5NBMbSPdk2";
$dbname = "feednui";
// 创建连接
$conn = mysqli_connect($servername, $username, $password, $dbname);
// Check connection
if (!$conn) {
    die("连接失败: " . mysqli_connect_error());
}
$sql = "SELECT * FROM `nature_plant` WHERE `plant_name` LIKE '%".$name."%'";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
    // 输出数据
    while($row = mysqli_fetch_assoc($result)) {
        $row = json_encode($row);
        echo ($row."//");
         //echo "name:".$row["name"]."Nutrients:".$row["Nutrients"]."<br>";   //echo "id: " . $row["id"]. " - Name: " . $row["gene"]. " " . $row["Nurtrents"]. "<br>";
    }
} else {
    echo "结果";
}


mysqli_close($conn);
?>