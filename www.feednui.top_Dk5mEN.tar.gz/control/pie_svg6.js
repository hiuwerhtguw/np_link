const oriData = [
      { 'x': 'A', 'y': 20 },
      { 'x': 'B', 'y': 40 },
      { 'x': 'C', 'y': 90 },
      { 'x': 'D', 'y': 80 },
      { 'x': 'E', 'y': 120 },
      { 'x': 'F', 'y': 100 },
      { 'x': 'G', 'y': 60 }
    ];
const [width, height] = [280, 280];

let svg = d3.selectAll('.svg6')
      .attr('width', width)
      .attr('height', height)

let g = svg.append('g')
      .attr('transform', 'translate( 40, 20 )')

    //设置饼图的半径
let radius = Math.min(width, height) * 0.8 / 2
console.log(radius)

let arc = d3.arc()
      .innerRadius(70)
      // .outerRadius(radius)
      .cornerRadius(10)
console.log(arc)
    //饼图与文字相连的曲线起点
let pointStart = d3.arc()
      .innerRadius(radius)
      .outerRadius(radius)
    //饼图与文字相连的曲线终点
let pointEnd = d3.arc()
      .innerRadius(radius + 20)
      .outerRadius(radius + 20)

let drawData = d3
      .pie()
      .value(function(d) {
        return d.y
      })
      .sort(null)
      .sortValues(null)
      .startAngle(0)
      .endAngle(Math.PI * 2)
      .padAngle(0.05)(oriData)
    console.log(drawData)

let colorScale = d3
      .scaleOrdinal()
      .domain(d3.range(0, oriData.length))
      .range(d3.schemeSet1);
g.append('g')
      .attr('transform', 'translate( ' + radius + ', ' + radius + ' )')
      .attr('stroke', 'steelblue')
      .attr('stroke-width', 1)
      .selectAll('path')
      .data(drawData)
      .enter()
      .append('path')
      .attr('fill', function(d) {
        return colorScale(d.index)
      })
      .attr('d', function(d) {
        d.outerRadius = radius;
        return arc(d)
      })
      .on('mouseover', arcTween(radius + 20, 0))
      .on('mouseout', arcTween(radius, 150))
      .transition()
      .duration(2000)
      .attrTween('d', function (d) {
      //初始加载时的过渡效果
        let fn = d3.interpolate({
          endAngle: d.startAngle
        }, d)
        return function(t) {
          return arc(fn(t))
        }
      })

function arcTween(outerRadius, delay) {
      // 设置缓动函数,为鼠标事件使用
      return function() {
        d3.select(this)
          .transition()
          .delay(delay)
          .attrTween('d', function(d) {
            let i = d3.interpolate(d.outerRadius, outerRadius)
            return function(t) {
              d.outerRadius = i(t)
              return arc(d)
            }
          })
      }
    }
    //文字层
let sum = d3.sum(oriData, d => d.y);
g.append('g')
      .attr('transform', 'translate( ' + radius + ', ' + radius + ' )')
      .selectAll('text')
      .data(drawData)
      .enter()
      .append('text')
      .attr('transform', function(d) {
      // arc.centroid(d)将文字平移到弧的中心
        return 'translate(' + arc.centroid(d) + ') ' +
          //rotate 使文字旋转扇形夹角一半的位置(也可不旋转)
          'rotate(' + (-90 + (d.startAngle + (d.endAngle - d.startAngle)/2) * 180 / Math.PI) + ')'
      })
			//文字开始点在文字中间
      .attr('text-anchor', 'middle')
			//文字垂直居中
      .attr('dominant-baseline', 'central')
      .attr('font-size', '10px')
			//格式化文字显示格式
      .text(function(d) {
        return (d.data.y / sum * 100).toFixed(2) + '%';
      })    
    
    
    
    



