function upCiyun(tid,data){
        var wc = new Js2WordCloud(document.getElementById(tid))
            wc.setOption({
            tooltip: {
                        show: true
                    },
            list: data,
            color: '#15a4fa'
                }) 
      }

function searchinfo(search_text){
var result_node =[]
 $.ajax({
                url:"search/search_info.php",
                type:"POST",
                async:false,
                data:{
                    "test":search_text,
                },
                success:function(data){
                test=data.split("//")
                test.pop()
                console.log(test)
                for (var i in test) {
                result_node.push(JSON.parse(test[i]))}
                console.log(result_node)     
                }
            })
return result_node
console.log(result_node)
}
const app = Vue.createApp({
  data() {
    return {
      newTodoText: '',
      todos: '',
      nextTodoId: 4,
      awesome:true
    }
  },
   watch:{
      awesome(c,o){
          if(o){
              console.log("触发词云")
              setTimeout(() => {
              console.log("B");
                  upCiyun("text1",[['1,1,6-trimethyl-2H-naphthalene', 80], ['11Z-hexadecenoic acid', 80], ['cedrol', 70], ['cyanin', 70], ['tetradecane', 60], ['worenine', 60],['2,21-Dimethyldocosane',50]])
                  upCiyun("text2",[['Amnesia', 80], ['Inflammatory dermatosis', 80], ['Benign Neoplasm', 70], ['Tumor Promotion', 70], ['Refractory Cytopenia of Childhood', 60], ['Dupuytren Disease', 60],['Depressive disorder', 80], ['Inflammatory dermatosis', 80], ['Benign Neoplasm', 70], ['melanoma', 70], ['', 60], ['Atrial Fibrillation', 60]])
                  upCiyun("text3",[['CASP9', 80], ['Tstap198-15', 80], ['RFK', 70], ['MYC', 70], ['ADRB2', 60], ['ADRB1', 60],['PM20D2', 80], ['POLD1', 80], ['PGD', 70], ['Api5-ps', 70], ['BAX', 60], ['VEGFA', 60],['PGR', 70], ['Cox20b', 70], ['CXCL8', 60], ['SOD1', 60]])
                  upCiyun("text4",[['sgogjgd', 80], ['nfkb', 80], ['nl-6', 70], ['il-8', 70], ['oxker', 60], ['inf', 60]])
   
                  

                  
                }, 10);
              
          }
          
      }
  },
  mounted(){
      this.todos = searchinfo("白")
  },
  methods: {
    addNewTodo() {
      this.todos = searchinfo(this.newTodoText)
    },
   
  }
})
app.component('div-counter',
{
  template:`
        <a href="#" class="list-group-item list-group-item-action py-3 lh-tight">
        <div class="d-flex w-100 align-items-center justify-content-between">
        <strong class="mb-1">{{ title.plant_name }}</strong>
        <small>研究文献数量{{ title.DOI}}</small>
        </div>
        <div class="col-10 mb-1 small">{{ title.represent }}
        </div>
        <button class="btn btn-primary" v-on:click="$emit('remove')">查看更多信息</button>
        </a>
        `,
  
  props: ['title'],
  emits: ['remove']
}
)

app.component('div-counter01', {
 methods:{
     
  searchtext(){
   
   return "枸杞子"
  }
 },
 
 template: 
  `
<div class="container-md">
<div class="container">
<h1>{{searchtext()}}包含的活性物质:</h1>
<h4>可饲用天然植物研究主题下的命名实体识别数据中活性物质数据进行统计</h5>
<div id="text1" style="height: 100px;" class="container"></div>
</div>

<div class="container">
<h1>{{searchtext()}}的潜在功效:</h1>
<h5>疾病名称被规定为这种可饲用天然植物研究主题下的潜在功效</h5>
<div id="text2" style="height: 100px;"></div>
</div>

<div class="container">
<h1>{{searchtext()}}相关的基因:</h1>
<h5>本研究将每种可饲用天然植物研究主题下的命名实体识别数据中基因数据进行统计。基因名称被规定为这种可饲用天然植物的相关的基因</h5>
<div id="text3" style="height: 100px;"></div>
</div>

<div class="container">
<h1>{{searchtext()}}可能作用到的蛋白:</h1>
<h5>本研究将每种可饲用天然植物研究主题下的命名实体识别数据中蛋白数据进行统计。蛋白名称被规定为这种可饲用天然植物的潜在的作用靶点</h5>
<div id="text4" style="height: 100px;"></div>
</div>
</div>

  `
})

app.mount('#v-model-basic')    








