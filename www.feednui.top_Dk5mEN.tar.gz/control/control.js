function control(){
var test01 = $("#test08").val()//获取检索数据
var test = $.post( "search/search.php", {test: test01}, 
function(data,status){
},"JSON")
$("#demo77").remove()
var app = new vue(
    {
        el:'#app',

    }

    )
}

function table(){
    
    
Vue.component('todo-item', {
props: ['todo'],
template: '<th>1</th> <td>Mark</td> <td>Otto</td> <td>@mdo</td>'
})

var app = new Vue({
  el: '#app',
  data: {
    groceryList: [
      { id: 0, text: '蔬菜' },
      { id: 1, text: '奶酪' },
      { id: 2, text: '随便其它什么人吃的东西' }
    ]
  }
})
    
    
}